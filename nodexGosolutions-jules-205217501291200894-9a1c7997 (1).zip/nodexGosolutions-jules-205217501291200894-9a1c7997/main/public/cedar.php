<?php
/**
 * cedar.php
 *
 * Renders CEO & Lead Architect's strategic mandate.
 * Styled with premium Tailwind CSS and modular elements.
 */

declare(strict_types=1);
require_once __DIR__ . '/../../php/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?= renderSeoHead([
        'title' => 'Founder mandate | nodexGosolutions',
        'description' => 'Cedar Anyanwu directs the corporate growth trajectory and system architecture of nodexGosolutions.',
        'og_title' => 'Cedar Anyanwu - Founder, CEO & Systems Architect',
        'og_description' => 'African startups should not be burdened by heavy subscription overhead or complex database administration.',
        'images' => ['/main/assets/images/cedar-anyanwu.jpg'],
        'og_type' => 'profile',
        'schema_type' => 'Person',
        'name' => 'Cedar Anyanwu',
        'jobTitle' => 'Chief Executive Officer',
        'organization' => 'Nodexplatform',
        'sameAs' => ['https://linkedin.com'],
        'breadcrumbs' => [
            ['name' => 'Founder Mandate', 'url' => '/cedar']
        ]
    ]) ?>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@300;400;600;700&family=Orbitron:wght@600;700;900&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 text-slate-700 min-h-screen flex flex-col justify-between">

    <?php require_once __DIR__ . '/../modul/nav.html'; ?>

    <main class="container mx-auto max-w-4xl my-16 px-4">
        <div class="bg-white border border-slate-100 rounded-2xl p-8 md:p-12 shadow-sm">
            <div class="flex flex-col md:flex-row gap-8 items-center mb-8">
                <!-- SEO Optimised Profile Container: Displaying the real Cedar Anyanwu photo with descriptive alt tag and cache-busting -->
                <!-- Change object-cover to custom styles to ensure face is fully visible on the avatar layout -->
                <div class="w-24 h-24 flex-shrink-0">
                    <?= renderEntityImage(
                        'Cedar Anyanwu',
                        '/main/assets/images/cedar-anyanwu.jpg',
                        'CEO of Nodexplatform',
                        'rounded-full w-24 h-24 object-contain object-top bg-slate-100 border-4 border-blue-100 shadow-sm cursor-pointer hover:opacity-90 transition-opacity',
                        'onclick="openImageModal(this.src, this.alt)"'
                    ) ?>
                </div>
                <div>
                    <!-- Section Title detailing the Founder Name in premium typography -->
                    <h1 class="text-3xl font-extrabold text-slate-900" style="font-family: 'Orbitron', sans-serif;">Cedar Anyanwu</h1>
                    <!-- Designation sub-header styled with corporate accent blue -->
                    <p class="text-blue-600 font-semibold">Founder, CEO & Systems Architect</p>
                </div>
            </div>

            <div class="prose max-w-none text-slate-600 flex flex-col gap-6 text-sm leading-relaxed">
                <p>Cedar Anyanwu directs the corporate growth trajectory of nodexGosolutions. With over a decade of experience designing lightweight modular software frameworks, space remote sensing downlinks, and high-performance server pipelines, Cedar leads our agile engineering teams to innovate at the frontier of technology.</p>

                <p class="font-bold text-slate-900 border-l-4 border-blue-600 pl-4 italic">"African startups should not be burdened by heavy subscription overhead or complex database administration. Our zero-database architectures allow businesses to host complex computations at virtually zero cost."</p>

                <h3 class="text-lg font-bold text-slate-900 mt-4">Pioneering GIS & Space Science Adoption</h3>
                <p>Under Cedar's vision, nodexGosolutions downlinks orbital metrics and delivers soil moisture, deforestation, and land tracking data directly to African research teams. We make complex spatial telemetry accessible to local developers via streamlined API channels.</p>
            </div>
        </div>
    </main>

    <?php require_once __DIR__ . '/../modul/footer.html'; ?>

    <!-- Interactive Reusable Image Modal System for SEO Images -->
    <div
        id="seoImageModal"
        class="fixed inset-0 z-[9999] hidden bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 transition-opacity duration-300 opacity-0"
        onclick="closeImageModalOnBackdrop(event)"
    >
        <div class="relative max-w-3xl w-full bg-white rounded-2xl overflow-hidden shadow-2xl border border-slate-100 transform scale-95 transition-transform duration-300" onclick="event.stopPropagation()">
            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100">
                <h3 id="seoModalTitle" class="text-base font-bold text-slate-900 truncate">Image View</h3>
                <button
                    type="button"
                    class="text-slate-400 hover:text-slate-600 focus:outline-none p-1"
                    onclick="closeImageModal()"
                >
                    <i class="fa-solid fa-xmark text-xl"></i>
                </button>
            </div>
            <!-- Modal Body (Image Container) -->
            <div class="p-6 flex justify-center bg-slate-50">
                <img
                    id="seoModalImage"
                    src=""
                    alt=""
                    class="max-h-[70vh] w-auto object-contain rounded-lg shadow-sm border border-slate-200"
                />
            </div>
        </div>
    </div>

    <!-- JavaScript to control the image modal behavior dynamically -->
    <script>
        /**
         * Opens the SEO image modal, populates the source/alt attributes, and plays smooth transition.
         * @param {string} src - The image source URL.
         * @param {string} alt - The descriptive SEO alt tag text.
         */
        function openImageModal(src, alt) {
            const modal = document.getElementById('seoImageModal');
            const modalImg = document.getElementById('seoModalImage');
            const modalTitle = document.getElementById('seoModalTitle');

            if (!modal || !modalImg || !modalTitle) return;

            // Set dynamic attributes
            modalImg.src = src;
            modalImg.alt = alt;
            modalTitle.textContent = alt || "Uncropped Full View";

            // Unhide modal element
            modal.classList.remove('hidden');

            // Allow layout render, then trigger CSS transitions
            setTimeout(() => {
                modal.classList.remove('opacity-0');
                modal.querySelector('.transform').classList.remove('scale-95');
                modal.querySelector('.transform').classList.add('scale-100');
            }, 20);

            // Close modal on Escape key down
            document.addEventListener('keydown', handleEscapeKey);
        }

        /**
         * Closes the interactive image modal with smooth fade-out CSS transitions.
         */
        function closeImageModal() {
            const modal = document.getElementById('seoImageModal');
            if (!modal) return;

            modal.classList.add('opacity-0');
            modal.querySelector('.transform').classList.remove('scale-100');
            modal.querySelector('.transform').classList.add('scale-95');

            // Hide from DOM after transition completes
            setTimeout(() => {
                modal.classList.add('hidden');
            }, 300);

            // Clean up global keydown listener
            document.removeEventListener('keydown', handleEscapeKey);
        }

        /**
         * Helper to safely close modal when clicking on the transparent backdrop.
         */
        function closeImageModalOnBackdrop(event) {
            closeImageModal();
        }

        /**
         * Handles Escape key press to close modal.
         */
        function handleEscapeKey(event) {
            if (event.key === 'Escape') {
                closeImageModal();
            }
        }
    </script>

</body>
</html>
